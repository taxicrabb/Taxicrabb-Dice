Hooks.on('diceSoNiceReady', (dice3d) => {

	dice3d.addTexture("Mapleleaf", {
	    name: "⧋ Maple Leaf",
	    composite: "multiply",
	    source: "modules/taxicrabb-dice/textures/Mapleleaftext.webp",
	    bump: "modules/taxicrabb-dice/textures/Mapleleaftext.webp"
	});
});
